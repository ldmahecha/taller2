package co.edu.sena.formulario.util;

import java.sql.Connection;

public class BasicDataSource {
    public void setUrl(String url) {
    }

    public void setUsername(String user) {
    }

    public void setPassword(String pass) {
    }

    public void setInitialSize(int i) {
    }

    public void setMinIdle(int i) {
    }

    public void setMaxIdle(int i) {
    }

    public void setMaxTotal(int i) {
    }

    public Connection getConnection() {
        return null;
    }
}




