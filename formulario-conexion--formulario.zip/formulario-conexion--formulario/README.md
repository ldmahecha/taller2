# formulario-conexion-
encriptar
![image](https://user-images.githubusercontent.com/125519146/236600116-d9b25b78-ebcd-4166-b948-4516ec51804d.png)
desencriptar 
![image](https://user-images.githubusercontent.com/125519146/236600154-082b020e-67c1-482c-a8b8-5965fc086190.png)
![image](https://user-images.githubusercontent.com/125519146/236600241-01479251-1214-44e3-8492-bb841aeb2f3d.png)
![image](https://user-images.githubusercontent.com/125519146/236600269-45b6c290-ecd3-4d4d-80ef-0ac1abcba321.png)
![image](https://user-images.githubusercontent.com/125519146/236600314-13ea3ab1-fce1-4abf-ba7d-c65b27866211.png)
![image](https://user-images.githubusercontent.com/125519146/236600354-033d7452-c51d-43c8-b647-6d4a3a4685d4.png)


